package com.example.myapplication1.pokeapi;

import com.example.myapplication1.models.Pokemonrepository;
import retrofit2.Call;
import retrofit2.http.GET;

public interface pokeapiServer {
    @GET("pokemon")
    Call<Pokemonrepository> obtenerlistpokemon();
}
