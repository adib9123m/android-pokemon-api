package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.myapplication1.models.Pokemon;
import com.example.myapplication1.models.Pokemonrepository;
import com.example.myapplication1.pokeapi.pokeapiServer;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
   private Retrofit retrofit;
   private static final String TAG="POKEDEX";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        retrofit = new Retrofit.Builder()
                .baseUrl("https://pokeapi.co/api/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        obtenerDatos();
    }

    private void obtenerDatos() {
        pokeapiServer service =retrofit.create(pokeapiServer.class);
        Call<Pokemonrepository> pokemonrepositoryCall = service.obtenerlistpokemon();

        pokemonrepositoryCall.enqueue(new Callback<Pokemonrepository>() {
            @Override
            public void onResponse(Call<Pokemonrepository> call, Response<Pokemonrepository> response) {
                if(response.isSuccessful()){
                    Pokemonrepository pokemonrepository = response.body();
                    ArrayList<Pokemon> listPokemon = pokemonrepository.getResults();

                    for(int i=0;i< listPokemon.size();i++){
                        Pokemon p =listPokemon.get(i);
                        Log.i(TAG,"Pokemon :"+p.getName());
                    }
                }else{
                    Log.e(TAG,"onResponse :"+response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<Pokemonrepository> call, Throwable t) {
               Log.e(TAG,"onFailure"+t.getMessage());
            }
        });
    }
}